#include"mcc.h"
uchar a,a1,b1,c1,h1,b,c,d,e,f,g,h,i,e1,e2,dd,ee,ff,gg,dd1,ee1,ff1,gg1;
bit FLAG_RESET_ALARM,FLAG_CLOSE_BIT_IN,FLAG_OPEN_BIT_IN,FLAG_REMOVE_IN,FLAG_REMOVE_OPEN_IN,FLAG_REMOVE_CLOSE_IN,FLAG_LOCAL_OPEN_IN,FLAG_LOCAL_CLOSE_IN,FLAG_GND_LOCK_IN,FLAG_REMOVE_CLOSE_OPEN_IN,FLAG_LOCAL_CLOSE_OPEN_IN;
void INPUT_COLLECT(void)
{
    /////////////////////��բ��λ�ź�/////////////////////////////
    if(!CLOSE_BIT_IN_PORT)
    {
        a++;
        a1=0;
        if(a>5)
        {
            a = 6;
            FLAG_CLOSE_BIT_IN = 1;                
        }
    }
    else
    {
        a = 0;
        a1++;
        if(a1>5)
        {
            a1=6;
            FLAG_CLOSE_BIT_IN = 0; 
        }
    }
    /////////////////////��բ��λ�ź�/////////////////////////////
    if(!OPEN_BIT_IN_PORT)
    {
        b++;
        b1=0;
        if(b>5)
        {
            b = 6;
            FLAG_OPEN_BIT_IN = 1;
        }
    }
    else
    {
        b = 0;
        b1++;
        if(b1>5)
        {
            b1=6;
            FLAG_OPEN_BIT_IN = 0;
        }
    }
    /////////////////��բλ�ͺ�բλ�ź�ͬʱ����///////////////
    if((FLAG_CLOSE_BIT_IN)&&(FLAG_OPEN_BIT_IN))
    {
        FLAG_ALARM=1;
        FLAG_CLOSE_OPEN_BIT_IN=1;
        FLAG_MOTOR_IN=0;
        FLAG_MOTOR_OUT=0;
        test_time=0;
        motor_run_1s=0;  
        FLAG_REMOVE_OPEN_IN = 0;
        FLAG_REMOVE_CLOSE_IN = 0;
        FLAG_LOCAL_OPEN_IN = 0;
        FLAG_LOCAL_CLOSE_IN = 0;        
    }
  
    /////////////////////�ӵ������ź�/////////////////////////////      
    if((!GND_LOCK_IN_PORT)&&(E_LOCK_IN_PORT))
    {
        h++;
        h1=0;
        if(h>5)
        {
            h = 6;
            FLAG_GND_LOCK_IN = 1;
        }
    }
    else
    {
        h=0;
        h1++;
        if(h1>5)
        {
            h1=6;
            FLAG_GND_LOCK_IN = 0;
        }
    }
//        /////////////////////���������ź�/////////////////////////////      
//    if(!E_LOCK_IN_PORT)
//    {
//        hA++;
//        hA1=0;
//        if(hA>5)
//        {
//            hA = 6;
//            FLAG_GND_LOCK_IN = 1;
//        }
//    }
//    else
//    {
//        hA=0;
//        hA1++;
//        if(hA1>5)
//        {
//            hA1=6;
//            FLAG_GND_LOCK_IN = 0;
//        }
//    }
//////////////////////////////////��λ����/////////////////////////////////////      
    if(!LOCAL_TEST_SW_IN_PORT)
    {
        i++;
        if(i>5)
        {
            i = 6;
            FLAG_RESET_ALARM = 1;
        }        
    }
    else
    {
        i=0;
    }
///////////////////////////////���ֹͣ״̬������ӦԶ���͵�ָ��//////////////////////////////////////////////    
    if((!FLAG_MOTOR_IN)&&(!FLAG_MOTOR_OUT))
    {       
            if(!REMOVE_IN_PORT)     //Զ�������ź�
            {
                c++;
                c1=0;
                if(c>5)
                {
                    c = 6;
                    FLAG_REMOVE_IN = 1;
                }
            }
            else                    //�͵ز����ź�
            {
                c = 0;
                c1++;
                if(c1>5)
                {
                    c1=6;
                    FLAG_REMOVE_IN=0;
                }
            }
    }
    //////////////////////////////���ֹͣ״̬������ź�///////////////////////////////
if((!FLAG_MOTOR_IN)&&(!FLAG_MOTOR_OUT))
{    
    if((FLAG_REMOVE_CLOSE_OPEN_IN)||(FLAG_LOCAL_CLOSE_OPEN_IN)||FLAG_GND_LOCK_IN_break||FLAG_CLOSE_OPEN_BIT_IN)     //�쳣״̬
    {
        /////////////////////�ӵ������ź�/////////////////////////////      
        if((!GND_LOCK_IN_PORT)&&(!E_LOCK_IN_PORT))
        {
            h++;
            h1=0;
            if(h>5)
            {
                h = 6;
                FLAG_GND_LOCK_IN = 1;
            }
        }
        else
        {
            h=0;
            h1++;
            if(h1>5)
            {
                h1=6;
                FLAG_GND_LOCK_IN = 0;
            }
        }
    /////////////////////ң�ط�բ�ͷ�ָ��/////////////////////////////   
        if((REMOVE_OPEN_IN_PORT))
        {
            dd++;
            dd1=0;
            if(dd>5)
            {
                dd = 6;
                FLAG_REMOVE_OPEN_IN = 0;
            }
        }
        else
        {
            dd = 0;
            dd1++;
            if(dd1>5)
            {
                dd1=6;
                FLAG_REMOVE_OPEN_IN = 1;
            }
        }
        /////////////////////ң�غ�բ�ͷ�ָ��/////////////////////////////      
        if((REMOVE_CLOSE_IN_PORT))
        {
            ee++;
            if(ee>5)
            {
                ee = 6;
                FLAG_REMOVE_CLOSE_IN = 0;        
            }
        }    
        else
        {
            ee=0;
            ee1++;
            if(ee1>5)
            {
                ee1=6;
                FLAG_REMOVE_CLOSE_IN = 1; 
            }
        }
    /////////////////////�͵ط�բ�ͷ�ָ��/////////////////////////////  
        if((LOCAL_OPEN_IN_PORT))
        {
            ff++;
            if(ff>5)
            {
                ff = 6;
                FLAG_LOCAL_OPEN_IN = 0;          
            }
        }  
        else
        {
            ff=0;
            ff1++;
            if(ff1>5)
            {
                ff1=6;
                FLAG_LOCAL_OPEN_IN = 1;  
            }
        }
        /////////////////////�͵غ�բ�ͷ�ָ��/////////////////////////////       
        if((LOCAL_CLOSE_IN_PORT))
        {
            gg++;
            if(gg>5)
            {
                gg = 6;
                FLAG_LOCAL_CLOSE_IN = 0;           
            }
        }
        else
        {
            gg=0;
            gg1++;
            if(gg1>5)
            {
                gg1=6;
                FLAG_LOCAL_CLOSE_IN=1;
            }
        }
        if((!FLAG_LOCAL_CLOSE_IN)&&(!FLAG_LOCAL_OPEN_IN)&&(!FLAG_REMOVE_CLOSE_IN)&&(!FLAG_REMOVE_OPEN_IN))
        {
            FLAG_REMOVE_CLOSE_OPEN_IN=0;
            FLAG_LOCAL_CLOSE_OPEN_IN=0;
            test_time=0;
            motor_run_1s=0;  
            if(FLAG_GND_LOCK_IN)
            {
                FLAG_GND_LOCK_IN_break=0;
            }
            if(!FLAG_GND_LOCK_IN_break)
            {
                if((!FLAG_OPEN_BIT_IN)||(!FLAG_CLOSE_BIT_IN))
                {
                    FLAG_CLOSE_OPEN_BIT_IN=0;
                    FLAG_ALARM = 0;
                }
            }
        }
    }  
////////////////////////////////���ֹͣ������״̬///////////////////////////////////////////////////    
    else        
    {
        if(FLAG_GND_LOCK_IN)                //�ӵ������ź�����
        {                
        /////////////////////ң�ط�բָ��/////////////////////////////   
            if((!REMOVE_OPEN_IN_PORT))
            {
                d++;
                if(d>5)
                {
                    d = 6;
                    FLAG_REMOVE_OPEN_IN = 1;
                }
            }
            else
            {
                d=0;
            }
            /////////////////////ң�غ�բָ��/////////////////////////////      
            if((!REMOVE_CLOSE_IN_PORT))
            {
                e++;
                if(e>5)
                {
                    e = 6;
                    FLAG_REMOVE_CLOSE_IN = 1;          
                }
            }
            else
            {
                e=0;
            }
        /////////////////////�͵ط�բָ��/////////////////////////////  
            if((!LOCAL_OPEN_IN_PORT))
            {
                f++;
                if(f>5)
                {
                    f = 6;
                    FLAG_LOCAL_OPEN_IN = 1;           
                }
            }    
            else
            {
                f=0;
            }
            /////////////////////�͵غ�բָ��/////////////////////////////       
            if((!LOCAL_CLOSE_IN_PORT))
            {
                g++;
                if(g>5)
                {
                    g = 6;
                    FLAG_LOCAL_CLOSE_IN = 1;             
                }
            }
            else
            {
                g=0;
            }
        }
            if((FLAG_LOCAL_CLOSE_IN)&&(FLAG_LOCAL_OPEN_IN))
            {
                FLAG_ALARM = 1;
                FLAG_LOCAL_CLOSE_OPEN_IN=1;            
            }       
            if((FLAG_REMOVE_CLOSE_IN)&&(FLAG_REMOVE_OPEN_IN))
            {
                FLAG_ALARM = 1;
                FLAG_REMOVE_CLOSE_OPEN_IN=1;
            }        
        if(FLAG_REMOVE_IN)          //Զ�������ź�
        {       
                if((FLAG_LOCAL_CLOSE_IN))      //Զ������ʱ�����ھ͵�ָ��
                {
                    FLAG_LOCAL_CLOSE_IN=0;
                }
                if((FLAG_LOCAL_OPEN_IN)) 
                {
                    FLAG_LOCAL_OPEN_IN=0;
                }
            
        }
        else                        //�͵ز����ź�
        {        
                if((FLAG_REMOVE_CLOSE_IN))       //�͵ز���ʱ������Զ��ָ��
                {
                    FLAG_REMOVE_CLOSE_IN=0;          
                }        
                if((FLAG_REMOVE_OPEN_IN))
                {
                    FLAG_REMOVE_OPEN_IN=0;
                }
        }          
        /////////////////////////////////////////////////
        if(FLAG_GND_LOCK_IN)                //�ӵ������ź�����
        {        
            if((FLAG_CLOSE_BIT_IN)&&(!FLAG_OPEN_BIT_IN))                          //�ں�բλ,���ڷ�բλ��ֻ�ܽ��з�բ
            {
                if(FLAG_REMOVE_IN)          //Զ����բ����
                {
                    if(FLAG_REMOVE_CLOSE_IN)    //��բָ�����ε�
                    {
                        FLAG_REMOVE_CLOSE_IN=0;
                    }                   
                    if((FLAG_REMOVE_OPEN_IN))
                    {
                        FLAG_MOTOR_OUT=1;
                        FLAG_MOTOR_IN=0;
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                    }             
                }
                else                        //�͵ط�բ����
                {     
                    if(FLAG_LOCAL_CLOSE_IN)    //��բָ�����ε�
                    {
                        FLAG_LOCAL_CLOSE_IN=0;
                    }                      
                    if((FLAG_LOCAL_OPEN_IN)) 
                    {
                        FLAG_MOTOR_OUT=1;
                        FLAG_MOTOR_IN=0;
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                    }
                }        
            }   
            else if((!FLAG_CLOSE_BIT_IN)&&(FLAG_OPEN_BIT_IN))                          //�ڷ�բλ,���ں�բλ��ֻ�ܽ��к�բ
           {          
               if(FLAG_REMOVE_IN)          //Զ����բ����
               {
                    if(FLAG_REMOVE_OPEN_IN)    //��բָ�����ε�
                    {
                        FLAG_REMOVE_OPEN_IN=0;
                    }                      
                   if((FLAG_REMOVE_CLOSE_IN))
                   {
                        FLAG_MOTOR_OUT=0;
                        FLAG_MOTOR_IN=1;
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                   }
               }
               else                        //�͵غ�բ����
               {       
                    if(FLAG_LOCAL_OPEN_IN)    //��բָ�����ε�
                    {
                        FLAG_LOCAL_OPEN_IN=0;
                    }                      
                   if((FLAG_LOCAL_CLOSE_IN)) 
                   {
                        FLAG_MOTOR_OUT=0;
                        FLAG_MOTOR_IN=1;
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                   }               
               } 
            }
            else if((!FLAG_CLOSE_BIT_IN)&&(!FLAG_OPEN_BIT_IN))         //���ں�բλ�����ڷ�բλ��ֻ�ܽ��з�բ����(����Ϊ������Ӧ�ֺ�բָ��)
            {
                if(FLAG_REMOVE_IN)          //Զ���ź�
                {
                    if(FLAG_REMOVE_CLOSE_IN)    //Զ����բָ�����ε�
                    {
                        FLAG_REMOVE_CLOSE_IN=0;
                    }
                    if(FLAG_REMOVE_OPEN_IN)      //Զ����բָ��
                    {
                        FLAG_MOTOR_IN=0;
//********************����Ӧ�ֺ�բָ��*******************/
                        FLAG_MOTOR_OUT=0;           
/*******************************************************/
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                    }
                }
                else                        //�͵��ź�
                {
                    if(FLAG_LOCAL_CLOSE_IN)    //�͵غ�բָ�����ε�
                    {
                        FLAG_LOCAL_CLOSE_IN=0;
                    }
                    if(FLAG_LOCAL_OPEN_IN)     //�͵ط�բָ��
                    {
                        FLAG_MOTOR_IN=0;
                        FLAG_MOTOR_OUT=0;
                        FLAG_REMOVE_OPEN_IN = 0;
                        FLAG_REMOVE_CLOSE_IN = 0;
                        FLAG_LOCAL_OPEN_IN = 0;
                        FLAG_LOCAL_CLOSE_IN = 0;
                    }
                }
            }
        }        
    }
}
    if((FLAG_MOTOR_IN)&&(!FLAG_MOTOR_OUT))
    {
        /////////////////////////////////////////////////           
        if((FLAG_CLOSE_BIT_IN)||(!FLAG_GND_LOCK_IN))                          //�ں�բλ,���ڷ�բλ��ֻ�ܽ��з�բ
        {
            FLAG_MOTOR_IN=0;
            FLAG_MOTOR_OUT=0;
            test_time=0;
            motor_run_1s=0;               
        }
        if(!FLAG_GND_LOCK_IN)
        {
            FLAG_ALARM=1; 
            FLAG_GND_LOCK_IN_break=1;                    
        } 
    }
    if((!FLAG_MOTOR_IN)&&(FLAG_MOTOR_OUT))
    {
        /////////////////////////////////////////////////           
        if((FLAG_OPEN_BIT_IN)||(!FLAG_GND_LOCK_IN))                        //�ڷ�բλ,���ں�բλ��ֻ�ܽ��к�բ
        {
            FLAG_MOTOR_IN=0;
            FLAG_MOTOR_OUT=0;
            test_time=0;
            motor_run_1s=0;                   
        }
        if(!FLAG_GND_LOCK_IN)
        {
            FLAG_ALARM=1; 
            FLAG_GND_LOCK_IN_break=1;          
        }   
    }
    if(FLAG_REMOVE_IN)
    {
        /////////////////////ң�طֺ�բָ��ͬʱ����/////////////////////////////     
        if((!REMOVE_CLOSE_IN_PORT)&&(!REMOVE_OPEN_IN_PORT))
        {
            e1++;
            if(e1>5)
            {
                e1 = 6;
                FLAG_ALARM = 1;
                FLAG_REMOVE_CLOSE_OPEN_IN=1;
                FLAG_MOTOR_IN=0;
                FLAG_MOTOR_OUT=0;
                test_time=0;
                motor_run_1s=0;                    
            }        
        }
        else
        {
            e1=0;
        }
    }    
    else
    {
        /////////////////////�͵طֺ�բָ��ͬʱ����/////////////////////////////       
        if((!LOCAL_CLOSE_IN_PORT)&&(!LOCAL_OPEN_IN_PORT))
        {
            e2++;
            if(e2>5)
            {
                e2 = 6;
                FLAG_LOCAL_CLOSE_OPEN_IN=1;
                FLAG_ALARM = 1;       
                FLAG_MOTOR_IN=0;
                FLAG_MOTOR_OUT=0;
                test_time=0;
                motor_run_1s=0;                    
            }
        } 
        else
        {
            e2=0;
        }
    }


/////////////////////////////////////////��λ������λ���б�־λ/////////////////////////////////////////////    
    if(FLAG_RESET_ALARM)
    {      
        FLAG_RESET_ALARM=0;
                RESET();
        FLAG_ALARM=0;
        FLAG_REMOVE_OPEN_IN = 0;
        FLAG_REMOVE_CLOSE_IN = 0;
        FLAG_LOCAL_OPEN_IN = 0;
        FLAG_LOCAL_CLOSE_IN = 0;
        FLAG_OVER_TIME_30S=0;
        FLAG_OVER_CURRENT=0;
        test_time=0;
        motor_run_1s=0;  
        FLAG_MOTOR_OUT = 0;
        FLAG_MOTOR_IN = 0; 
    }
/////////////////////////////////////////��ʱ/////////////////////////////
    if(FLAG_OVER_TIME_30S)
    {      
        FLAG_ALARM = 1;    
    }    
///////////////////////////////////����ʱ���ֹͣ����/////////////////////////////    
    if(FLAG_ALARM)
    {
        FLAG_MOTOR_OUT = 0;
        FLAG_MOTOR_IN = 0;    
    }  
///////////////////////////// ///////////////////////////// ///////////////////////////// ///////////////////////////// /////////////////////////////   

}

