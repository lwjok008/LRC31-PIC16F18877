#include"mcc.h"
bit FLAG_MOTOR_IN,FLAG_MOTOR_OUT,FLAG_ALARM,FLAG_CLOSE_OPEN_BIT_IN,FLAG_GND_LOCK_IN_break;
uchar out_order=1,out_stop_order=1,in_order=1,in_stop_order=1;
uint I_current=0;
uint led_time_10ms;
void OUTPUT_CTRL(void)
{

}
void LED_CTRL(void)
{
    if(FLAG_ALARM)
    {
        if(FLAG_OVER_TIME_30S)          //��ʱ����
        {
            if(FLAG_OVER_CURRENT)      //��ת����
            {
                led_time_10ms++;
                if(led_time_10ms>=3)
                {
                    led_time_10ms=0;
                    LED_ALARM_LAT = ~LED_ALARM_LAT;
                }                 
            }
            else
            LED_ALARM_LAT=1;
        }
        else if((FLAG_GND_LOCK_IN_break))   //�ӵ������Ͽ�1����1����
        {
            led_time_10ms++;
            if(led_time_10ms>=25)
            {
                led_time_10ms=0;
                LED_ALARM_LAT = ~LED_ALARM_LAT;
            }        
        }
        else if((FLAG_LOCAL_CLOSE_OPEN_IN)||(FLAG_REMOVE_CLOSE_OPEN_IN))//�����쳣��0.1����0.9����
        {
            led_time_10ms++;
            if(led_time_10ms>=25)
            {
                led_time_10ms=0;
            }            
            if(led_time_10ms<=2)
            {
                LED_ALARM_LAT=1;
            }
            else
            {
                LED_ALARM_LAT=0;
            }
        }
        else if(FLAG_OVER_CURRENT)      //��ת����
        {
            led_time_10ms++;
            if(led_time_10ms>=3)
            {
                led_time_10ms=0;
                LED_ALARM_LAT = ~LED_ALARM_LAT;
            }            
            
//            if(led_time_10ms<=3)
//            {
//                LED_ALARM_LAT=0;
//            }
//            else
//            {
//                LED_ALARM_LAT=1;
//            }            
        }
        else
        {
            LED_ALARM_LAT=1;
        }
//        LED_ALARM_LAT=1;
        RLY_ALARM_LAT=1;
    }
    else
    {
        LED_ALARM_LAT=0;   
        RLY_ALARM_LAT=0;
    }
    if(FLAG_CLOSE_BIT_IN)
    {
        LED_CLOSE_LAT=1;
    }
    else
    {
        LED_CLOSE_LAT=0;    
    }
    if(FLAG_OPEN_BIT_IN)
    {
        LED_OPEN_LAT=1;
    }
    else
    {
        LED_OPEN_LAT=0;    
    }
}
void MOTOR_CTRL(void)
{
    ///////////////////��բ����////////////////
    if((FLAG_MOTOR_OUT)&&(!FLAG_MOTOR_IN))
    {
        out_stop_order=1;
        switch(out_order)
        {
            case 1:	
            {
                MOS_CLOSE_LAT=0;
                out_order=2;
            }break;
            case 2:	
            {  
                RLY_CLOSE_LAT=0;
                out_order=3;
            }break;               
            case 3:	
            {
                RLY_OPEN_LAT=1;
                out_order=4;
            }break;
            case 4:	
            {  
                MOS_OPEN_LAT=1;
                out_order=5;
                //ADCC_DischargeSampleCapacitor();
            }break; 
            case 5:	
            {
                ad_value_I_TEST = ADCC_GetSingleConversion(I_TEST);
//                I_current = ((2500*ad_value_I_TEST)>>10);
                if(ad_value_I_TEST>37)  //֮ǰΪ40=6.5A,37=6A,���㹫ʽ����0.03*I��/5*1024����������30m��
                {
                    FLAG_OVER_TIME_30S=1;
                    FLAG_OVER_CURRENT=1;
//                    FLAG_MOTOR_OUT = 0;
//                    FLAG_MOTOR_IN = 0;
//                    FLAG_REMOVE_OPEN_IN = 0;
//                    FLAG_LOCAL_OPEN_IN = 0;                     
//                    FLAG_ALARM = 1;
                }                 
            }            
        }
    }
    else if(!FLAG_MOTOR_OUT)
    {    
        out_order=1;
         switch(out_stop_order)
        {
            case 1:	
            {
                MOS_OPEN_LAT=0;
                out_stop_order=2;
            }break;
            case 2:	
            {  
                RLY_OPEN_LAT=0;
                out_stop_order=3;
            }break;        
        }
    }
    ///////////////////��բ����////////////////
    if((FLAG_MOTOR_IN)&&(!FLAG_MOTOR_OUT))
    {
        in_stop_order=1;
        switch(in_order)
        {
            case 1:	
            {
                MOS_OPEN_LAT=0;
                in_order=2;
            }break;
            case 2:	
            {  
                RLY_OPEN_LAT=0;
                in_order=3;
            }break;              
            case 3:	
            {
                RLY_CLOSE_LAT=1;
                in_order=4;
            }break;
            case 4:	
            {  
                MOS_CLOSE_LAT=1;
                in_order=5;
                //ADCC_DischargeSampleCapacitor();
            }break;
            case 5:	
            {
                ad_value_I_TEST = ADCC_GetSingleConversion(I_TEST);
                //I_current = ((2500*ad_value_I_TEST)>>10);
                if(ad_value_I_TEST>37)  //40=6.5A,37=6A,֮ǰΪ43=7A,���㹫ʽ����0.03*I��/5*1024����������30m��
                {
                    FLAG_OVER_TIME_30S=1;
                    FLAG_OVER_CURRENT=1;
//                    FLAG_MOTOR_OUT = 0;
//                    FLAG_MOTOR_IN = 0;
//                    FLAG_REMOVE_OPEN_IN = 0;
//                    FLAG_LOCAL_OPEN_IN = 0;                     
//                    FLAG_ALARM = 1;
                }                  
            }
        }
    }
    else if((!FLAG_MOTOR_IN))
    {
        
        in_order=1;
        switch(in_stop_order)
        {
            case 1:	
            {
                MOS_CLOSE_LAT=0;
                in_stop_order=2;
            }break;
            case 2:	
            {  
                RLY_CLOSE_LAT=0;
                in_stop_order=3;
            }break;        
        }    
    } 
}